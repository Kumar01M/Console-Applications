package manage;

public class Player {
	
	String playerName;
	int runsScored;
	int ballsPlayed;
	int runsGiven;
	int ballsBowled;
	int oversBowled;
	int wicketsTaken;
	int maidenOvers;
	boolean out;
	
	Player() {
		playerName = Scorecard.in.nextLine();
	}
	
}
