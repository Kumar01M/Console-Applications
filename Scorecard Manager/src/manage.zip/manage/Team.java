package manage;

import java.util.ArrayList;

class Team {
	String teamName;
	ArrayList<Player> teamList = new ArrayList<>();
	int teamPlayers = 11;
	
	Team() {
		System.out.println("Enter Team Name: ");
		teamName = Scorecard.in.nextLine();
	}
	
	void addTeamMembers() {
		System.out.println("Enter Team List");
		while(teamPlayers-- != 0) {
			teamList.add(new Player());
		}
	}
	
}