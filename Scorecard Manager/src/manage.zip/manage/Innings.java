package manage;

public class Innings {
	
	Player striker;
	Player nonStriker;
	Player bowler;
	
	int score;
	int fallOfWickets;
	int thisOver;
	int balls;
	int noOfOvers;
	
	static boolean chase = false;
	
	int initBatsman = 0;
	int initBowler = 10;
	
	static int total;
	boolean strikeRotated = false;
	
	
	void begin(Team battingTeam, Team bowlingTeam, int noOfOvers) {
		
		this.noOfOvers = noOfOvers;
				
		striker = battingTeam.teamList.get(initBatsman);
		nonStriker = battingTeam.teamList.get(++initBatsman);
		
		bowler = bowlingTeam.teamList.get(initBowler--);
			
		while(thisOver!=noOfOvers && fallOfWickets != 10) {
			System.out.println();
			scorecardUpdate(battingTeam, bowlingTeam);
			
			System.out.println("[0: Dot ball  1: 1 run  2: 2 runs  3: 3 runs  4: Four  6: Six  5: Penalty / Overthrow (5 runs)]");
			System.out.println("[7: Bold  8: Caught  9: Stumped 10: LBW (Leg Before Wicket) 11: Run-Out ]");
			System.out.println("Ball Instance:\n->>");
			String hit = Scorecard.in.nextLine();
			
			switch(hit) {
			case "1":
				score+=1;
				striker.runsScored ++;
				break;
			case "2":
				score+=2;
				striker.runsScored +=2;
				break;
			case "3":
				score+=3;
				striker.runsScored +=3;
				break;
			case "4":
				score+=4;
				striker.runsScored +=4;
				break;
			case "5":
				score+=5;
				striker.runsScored +=5;
				break;
			case "6":
				score+=6;
				striker.runsScored +=6;
				break;
			case "8":
				break;
			case "9":
				break;
			case "10":
				break;
			case "11":
				break;
			case "o":
				fallOfWickets +=1;
				striker = battingTeam.teamList.get(++initBatsman);
				bowler.wicketsTaken++;
				break;
			default:
				System.out.println("Wasted");
				break;
			}
			striker.ballsPlayed+=1;
			if(hit.equals("1")||hit.equals("3"))rotateStrike();
			
			balls++;
			bowler.ballsBowled +=1;
			if(balls==6) {
				thisOver+=1;
				rotateStrike();

				if(initBowler < 6) initBowler = 10;
				bowler = bowlingTeam.teamList.get(initBowler--);
				
				balls=0;
			}
			
			if(chase==true) {
				if(score>total)scorecardUpdate(battingTeam);
			}
		}
		
		if(chase==true) {
			scorecardUpdate(bowlingTeam);
		}
		
		chase = true;
		total = score;
							
	}
	
	void scorecardUpdate(Team battingTeam, Team bowlingTeam) {
		System.out.println("____________________________________________________________________________");
		if(strikeRotated == false) System.out.println("S \t"+battingTeam.teamName.substring(0,3).toUpperCase()+"\t"+score+" / "+fallOfWickets+ "\t*"+striker.playerName+" "+striker.runsScored+"("+striker.ballsPlayed+")\t"+nonStriker.playerName+" "+nonStriker.runsScored+"("+nonStriker.ballsPlayed+")");
		else System.out.println("S \t"+battingTeam.teamName.substring(0,3).toUpperCase()+"\t"+score+" / "+fallOfWickets+ "\t"+nonStriker.playerName+" "+nonStriker.runsScored+"("+nonStriker.ballsPlayed+")\t*"+striker.playerName+" "+striker.runsScored+"("+striker.ballsPlayed+")");
		System.out.println("C \t"+"\t\tOvers: "+thisOver+"."+balls+"\t "+bowler.playerName+" "+bowler.oversBowled+"."+bowler.ballsBowled+"-"+bowler.wicketsTaken);
		if(chase==false && thisOver>=1)System.out.println("O \t Current run rate: "+score/(thisOver*6)+balls);
		else System.out.println("O");
		if(chase==true && thisOver >=1)System.out.println("O \t Current run rate: "+score/(thisOver*6)+balls+"\tRequired run rate: "+(total-score)/(noOfOvers-thisOver*6)+balls);
		else System.out.println("O");
		if(chase==true)System.out.println("R \t Total: "+total);
		else System.out.println("R \t");
		System.out.println("E ");
		System.out.println("____________________________________________________________________________");

	}
	
	void scorecardUpdate(Team name) {
		System.out.println("***"+name.teamName+" team won***");
	}
	
	void rotateStrike() {
		Player temp = striker;
		striker = nonStriker;
		nonStriker = temp;
		if(strikeRotated==false) strikeRotated = true;
		else strikeRotated = false;
	}
	
	void changeBowler() {
	}
	
}
